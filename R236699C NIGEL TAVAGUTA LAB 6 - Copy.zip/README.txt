﻿Lab 6 submission package

Contents
- R236699C LAB 6.pdf: technical report
- lab6/: Python implementation, README, presentation outline, result CSV files, and figures

Run everything from the lab6 folder with:
  python run_all.py

This regenerates the CSV tables and plots in lab6/output. Python 3.12+ and matplotlib are required.

To rebuild the PDF, run `python build_pdf.py` from lab6. This also requires Pandoc and WeasyPrint. The script renders the report equations before creating the PDF.
